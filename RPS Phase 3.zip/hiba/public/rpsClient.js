var gameState ;

// turns the rock, paper, scissors into buttons
  $( document ).ready(function() {
    $("#gameBoard-paperImg").click(function(){
        recordMove("paper");
    });
    $("#gameBoard-scissorImg").click(function(){
        recordMove("scissor");
    });
    $("#gameBoard-rockImg").click(function(){
        recordMove("rock");
    });

});
//precondition: none
//postcondition: The window loads and the title page is displayed the rest of the divisions are hidden
window.onload = function(){
    document.getElementById("titlePage").style.display = "block";
    document.getElementById("gameBoardTop").style.display = "none";
    document.getElementById("gameBoardCenter").style.display = "none";
    document.getElementById("gameBoardBottom").style.display = "none";
    document.getElementById("gameBoardWon").style.display = "none";
}

//precondition: none
//postcondition: prompts asking player 1's and player 2's names, registerPlayers is called and player 1 and 2's names are sent as well as game type
function TwoPlayerButtonClick(){    
    var player1Name = prompt("Player 1 what is your name ?");    
    var player2Name = prompt("Player 2 what is your name ?");    
   registerPlayers(player1Name, player2Name,"twoPlayer");
}

//precondition: none
//postcondition: starts the game again, play again button is hidden, images are displayed
function PlayAgainClick(){    
    document.getElementById("gameBoardCenter").style.display = "none"; 
    document.getElementById("gameBoardBottom").style.display = "block";    
    const http = new XMLHttpRequest()
    http.open('POST', '/playAgain')
    http.setRequestHeader('Content-type', 'application/json')
    http.send();
    http.onload = function() {        
        console.log(http.responseText)
        gameState = JSON.parse(http.responseText);  
        gameBoard(gameState);
    }
}

//precondition: none
//postcondition: prompt asking player 1's names for the 1 player one game and registerPlayers is called, sending player q's name, cmputer as the second player and game type 
function OnePlayerButtonClick(){    
    var player1Name = prompt("what is your name ?");        
    registerPlayers(player1Name, "Computer", "onePlayer");    
}

//precondition: none
//postcondition: new object is created storing data of the players names, sending information to server side js******************************************** 
function registerPlayers(player1Name, player2Name, gameType) {
    var data = new Object();
    data.player1Name = player1Name;
    data.player2Name = player2Name;
    data.gameType = gameType;

    const http = new XMLHttpRequest()
    http.open('POST', '/registerPlayers')
    http.setRequestHeader('Content-type', 'application/json')
    http.send(JSON.stringify(data));
    console.log("Json sent to Server " + JSON.stringify(data));
    http.onload = function() {        
        console.log(http.responseText)
        gameState = JSON.parse(http.responseText);  
        gameBoard(gameState);
    }
}

//precondition: none
//postcondition: sets scoreboard and which players turn it is 
function refreshGameBoard(gameState){
    console.log("Playing player name is " +  gameState.playingPlayer.name);
    document.getElementById("gameBoard-h2").innerHTML = gameState.playingPlayer.name + "'s Turn ! ";    
    document.getElementById("gameBoard-th1").innerHTML = gameState.player1.name ;    
    document.getElementById("gameBoard-th2").innerHTML = gameState.player2.name ; 
    document.getElementById("gameBoard-td1").innerHTML = gameState.player1.score ; 
    document.getElementById("gameBoard-td2").innerHTML = gameState.player2.score ; 
 }

//precondition: none
//postcondition: displays scoreboard and images, hides other divisions
 function gameBoard(gameState){
    document.getElementById("titlePage").style.display = "none";    
    document.getElementById("gameBoardTop").style.display = "block";
    document.getElementById("gameBoardCenter").style.display = "none"; 
    document.getElementById("gameBoardBottom").style.display = "block"; 
    document.getElementById("gameBoardWon").style.display = "none"; 
    refreshGameBoard(gameState);
 }

//precondition: none
//postcondition: displays winner of each round, hides other divisions
 function winBoard(){
    document.getElementById("titlePage").style.display = "none";
    document.getElementById("gameBoardTop").style.display = "none";
    document.getElementById("gameBoardCenter").style.display = "none"; 
    document.getElementById("gameBoardBottom").style.display = "none"; 
    document.getElementById("gameBoardWon").style.display = "block"; 
    refreshGameBoard(gameState);
 }

//precondition: none
//postcondition: cslls gameBoard when next is clicked to go back to the playing board
 function NextButtonClick(){
    gameBoard(gameState);
 }

//precondition: none
//postcondition: data set to server side, sets table for each players choices ad winner of each round, displays the final winner if score of any player reaches 2
 function recordMove(selection) {
    var data = new Object();
    data.selection = selection;
    const http = new XMLHttpRequest()
    http.open('POST', '/recordMove')
    http.setRequestHeader('Content-type', 'application/json')
    http.send(JSON.stringify(data));
    console.log("Json sent to Server " + JSON.stringify(data));
    http.onload = function() {  
        console.log("Record Move " + http.responseText);
        gameState = JSON.parse(http.responseText);        
        refreshGameBoard(gameState);


        if (gameState.totalTurn % 2 == 0) { // 
            if ( gameState.winner != null){
                document.getElementById("gameBoard-h2").innerHTML = gameState.winner.name + " won this round! ";  
            }  else {
                document.getElementById("gameBoard-h2").innerHTML = "No Winner" ;
            }       
           winBoard(); //calls winboard to display the winner of each round
           document.getElementById("gameBoardWon-th1").innerHTML = gameState.player1.name ;  
           document.getElementById("gameBoardWon-th2").innerHTML = gameState.player2.name ;  
           document.getElementById("gameBoardWon-th3").innerHTML = "Winner of this round"  
           document.getElementById("gameBoardWon-td1").innerHTML = gameState.player1.selection ;  //displays player 1's selection
           document.getElementById("gameBoardWon-td2").innerHTML = gameState.player2.selection ;  //displays plaer 2's selection
           if (gameState.player1.selection != gameState.player2.selection) {
                document.getElementById("gameBoardWon-td3").innerHTML = gameState.winner.name ;  //displays winners name 
           } else {
                document.getElementById("gameBoardWon-td3").innerHTML = "none" ;  // if its a tie 
           }
        }
        

        if (gameState.player1.score == 2) { //if player 1 reaches 2 points
            console.log(gameState.player1.name + " won" + gameState.player1.score);
            document.getElementById("gameBoard-h2").innerHTML = gameState.player1.name +  "  WON THE BEST OF THREE!!!!!!";
            document.getElementById("gameBoardTop").style.display = "block"; 
            document.getElementById("gameBoardCenter").style.display = "block"; 
            document.getElementById("gameBoardBottom").style.display = "none";    
            document.getElementById("gameBoardWon").style.display = "none";
        } else if (gameState.player2.score == 2) { //if player 2 reaches 2 points
            console.log(gameState.player2.name + " won" + gameState.player2.score);
            document.getElementById("gameBoard-h2").innerHTML = gameState.player2.name +  "  WON THE BEST OF THREE!!!!!!";
            document.getElementById("gameBoardTop").style.display = "block"; 
            document.getElementById("gameBoardCenter").style.display = "block"; 
            document.getElementById("gameBoardBottom").style.display = "none";    
            document.getElementById("gameBoardWon").style.display = "none";
        }
    }
}

//precondition: none
//postcondition: alert is displayed, saying bye to the user, all divisions are hidden
function exit() {
    alert("Hope you had fun playing Rock Paper Scissors, Have a nice day. "); // exit message 
    document.getElementById("top").style.display = "none";
    document.getElementById("gameBoardTop").style.display = "none";
    document.getElementById("gameBoardCenter").style.display = "none";
    document.getElementById("gameBoardBottom").style.display = "none";
    document.getElementById("gameBoardWon").style.display = "none";


}

