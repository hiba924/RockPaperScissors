const express = require('express');
const path = require('path');
var bodyParser = require('body-parser')
const app = express();
app.use(express.json());
app.use(bodyParser.json())
const PORT = 3000;                 
app.use(express.static('.')); 
app.use('/images', express.static('images'));


var player1; //variable for player 1
var player2; //variable for player 2
var playingPlayer; //variable for player that is currently taking their turn 
var gameType ; //variable for if game is single player or two player 
var winner ; //variable for winner ofe= each round 
var totalTurn = 0 ; //variable for total turns taken by both players together 

//constructor for player 
class Player {
    constructor(name) {
      this.name = name;
      this.turn = 0;
      this.selection = "";
      this.score = 0;
    }    
  }

app.get('/', (req, res) => {  
  res.sendFile(path.join(__dirname, '/public/rps.html'));
});


app.post('/registerPlayers', (req, res) => {
  var reqData = JSON.parse(JSON.stringify(req.body));  
  player1 = new Player(reqData.player1Name);
  player2 = new Player(reqData.player2Name);
  playingPlayer = player1;
  gameType = reqData.gameType;

  var resdata = new Object();
  resdata.player1 = player1;
  resdata.player2 = player2;
  resdata.playingPlayer = playingPlayer;
  resdata.winner = winner;
  resdata.totalTurn=totalTurn;
  resdata.gameType = gameType;
  
  res.json(resdata);
  
});


app.post('/recordMove', (req, res) => {  
  totalTurn++ ;
  var reqData = JSON.parse(JSON.stringify(req.body));  
  recordMove(reqData.selection)
  var resdata = new Object();
     resdata.player1 = player1;
     resdata.player2 = player2;
     resdata.playingPlayer = playingPlayer;
     resdata.winner = winner;
     resdata.totalTurn=totalTurn;
     resdata.gameType = gameType;
  res.json(resdata);  
});


app.post('/playAgain', (req, res) => {  
  resetScore();
  var resdata = new Object();
     resdata.player1 = player1;
     resdata.player2 = player2;
     resdata.playingPlayer = playingPlayer;
     resdata.winner = winner;
     resdata.totalTurn=totalTurn;
     resdata.gameType = gameType;
  res.json(resdata);  
});


//precondition: none
//postcondition: determines the winner of each round based on each players selections, adds a score to the player who won, calls computerTurn if it's a one player game 
function recordMove(selection) {
   
  if (playingPlayer == player1) {        
      player1.turn++; // adds 1 to player 1's turn counter
      player1.selection = selection;  //adds selection to player 1's selection
      console.log("P1 " + playingPlayer.name + " is playing:  score: " + playingPlayer.score + "  turn:  " + playingPlayer.turn + " selection: " + playingPlayer.selection );  
      playingPlayer = player2;  //changes playing player to the second player because it is now their turn
      
      if (gameType == "onePlayer"){ // if the player is versing the computer
        totalTurn++ ; // adds a turn for the computer
          recordMove(computerTurn()); // calls record Move and uses computerTurn as the selection, computer is seen as player2
      }
      
  } else if (playingPlayer == player2){        
      player2.turn++; //adds 1 to player 2's tur counter 
      player2.selection = selection;  //adds selection to player 2's selection 
      console.log("P2 " + playingPlayer.name + " is playing:  score: " + playingPlayer.score + "  turn:  " + playingPlayer.turn + " selection: " + playingPlayer.selection );  
      playingPlayer = player1; //changes playing player to the second player because it is now their turn
              
      if (player1.selection == "rock" && player2.selection == "rock"){ // if both chose rock, it's a draw, nothing happens 
          console.log ("this round is draw  ........"); 
      } else if (player1.selection == "rock" && player2.selection == "paper"){ // if player 1 chose rock and player 2 chose paper
          player2.score++; //adds a score to player 2
          winner = player2; //player 2 wins 
          console.log (player2.name + " won " + player2.score);
      } else if (player1.selection == "rock" && player2.selection == "scissor"){ //if player 1 chose rock and player 2 chose scissors
          player1.score++; //adds a score to player 1
          winner = player1; //player 1 wins
          console.log (player1.name + " won " + player1.score);
      } else if (player1.selection == "scissor" && player2.selection == "rock"){ //if player 1 chose scissors and player 2 chose rock
          player2.score++; //adds a score to player 2
          winner = player2; //player 2 wins 
          console.log (player2.name + " won " + player2.score);
      } else if (player1.selection == "scissor" && player2.selection == "paper"){ //if player 1 chose scissors and player 2 chose paper
          player1.score++; //adds a score to player 1
          winner = player1; //player 1 wins
          console.log (player1.name + " won " + player1.score);
      } else if (player1.selection == "scissor" && player2.selection == "scissor"){ // if both chose scissors, it's a draw, nothing happens 
          console.log ("this round is draw  ........");
      } else if (player1.selection == "paper" && player2.selection == "rock"){ //if player 1 chose paper and player 2 chose rock
          player1.score++; //adds a score to player 1
          winner = player1; //player 1 wins
          console.log (player1.name + " won " + player1.score);
      } else   if (player1.selection == "paper" && player2.selection == "paper"){ // if both chose paper, it's a draw, nothing happens 
          console.log ("this round is draw  ........");
      } else if (player1.selection == "paper" && player2.selection == "scissor"){ //if player 1 chose paper and player 2 chose scissors
          player2.score++; //adds a score to player 2
          winner = player2; //player 2 wins 
          console.log (player2.name + " won " + player2.score);
          
      }   
      
  }
  
  if (player1.score == 2) {
      console.log(player1.name + " won" + player1.score);
  } else if (player2.score == 2) {
      console.log(player2.name + " won" + player2.score);
  }
  }

//precondition: none
//postcondition: random selection for computer's turn is chosen and returned
  function computerTurn() {
    var random =  Math.floor(Math.random()*3); //random number generator [0,2]
     if (random == 0)
         return "rock";
     if (random == 1)
         return "paper";
      if (random == 2)
         return "scissor";
 }

//precondition: none
//postcondition: resets varaibles after game is finished
  function resetScore() {
    totalTurn = 0 ; 
    player1.score = 0;
    player2.score = 0;
    player1.selection = "";
    player2.selection="";
    player1.turn = 0;
    player2.turn = 0;
    winner = null;
}

app.listen(PORT, () => {
  console.log(`Running server on PORT ${PORT}...`);
})
